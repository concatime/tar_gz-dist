/* liblzma is pretty close to zlib and bzlib.  */

#define LZMA
#include "gzip.c"
