/* libzstd is pretty close to zlib and bzlib.  */

#define ZSTD
#include "gzip.c"
