original=testfile11
stripped=testfile15
debugfile=testfile15.debug

. $srcdir/run-unstrip-test.sh
