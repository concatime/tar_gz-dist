original=testfile39
stripped=testfile40
debugfile=testfile40.debug

. $srcdir/run-strip-test.sh
