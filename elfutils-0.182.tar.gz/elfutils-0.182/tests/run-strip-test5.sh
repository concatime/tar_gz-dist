original=testfile8
stripped=testfile16
debugfile=testfile16.debug

. $srcdir/run-strip-test.sh
