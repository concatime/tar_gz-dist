static const AVBitStreamFilter * const bitstream_filters[] = {
    &ff_null_bsf,
    NULL };
