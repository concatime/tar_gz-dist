#! /bin/sh

. global-test-vars.sh

$CSSLINT "$TEST_INPUTS_DIR"/several-media.css
