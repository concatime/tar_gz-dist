enum {red1, green1, blue1} primary1;
