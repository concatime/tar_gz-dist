/* Looked up item by item. */
enum e { ENUMSAMPLE_1 = 0, ENUMSAMPLE_2 = 1 };

/* Looked up via both sorts of iterator in turn.  */
enum ie { IENUMSAMPLE_1 = -10, IENUMSAMPLE_2, IENUMSAMPLE_3 };

enum e foo;
enum ie bar;
