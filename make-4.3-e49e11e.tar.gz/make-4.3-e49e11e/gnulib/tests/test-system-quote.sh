#!/bin/sh

${CHECKER} ./test-system-quote-main${EXEEXT} ./test-system-quote-child${EXEEXT}
