/* Print the version number.  */

void version (void);
