#include "backupfile.h"
#include <stdbool.h>
extern char *backupfile_internal (char const *, enum backup_type, bool);
