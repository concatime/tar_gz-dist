#define UNSIGNED 1
#include "strtoimax.c"
