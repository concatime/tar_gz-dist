#!/bin/sh

exec ./test-ftruncate${EXEEXT} "$srcdir/test-ftruncate.sh"
