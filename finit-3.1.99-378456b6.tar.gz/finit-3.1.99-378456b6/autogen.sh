#!/bin/sh

autoreconf -W portability -vifm
