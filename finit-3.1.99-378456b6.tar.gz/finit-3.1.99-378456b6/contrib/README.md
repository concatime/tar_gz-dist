Finit Examples
==============

This section provides configuration examples and helpful tools to
install and try out Finit on various Linux distributions.

* [Alpine](alpine/)
* [Debian](debian/)

If you have ideas on how to simplify, extend, or even add new example
configurations for other distributions you are most welcome! :)

