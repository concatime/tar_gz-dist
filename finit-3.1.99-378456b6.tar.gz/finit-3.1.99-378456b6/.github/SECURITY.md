# Security Policy

## Supported Versions

finit is a small project, as such we have no possibility to support older versions.
The only supported version is the latest released on GitHub:

<https://github.com/troglobit/finit/releases>

## Reporting a Vulnerability

Contact the project's main author and owner to report and discuss vulnerabilities.
