#!/bin/bash

set -e

./tst-pam_motd1.sh
./tst-pam_motd2.sh
./tst-pam_motd3.sh
./tst-pam_motd4.sh
