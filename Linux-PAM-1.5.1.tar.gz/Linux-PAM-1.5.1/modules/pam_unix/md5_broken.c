#define MD5Name(x) Broken##x

#include "md5.c"
#include "md5_crypt.c"
