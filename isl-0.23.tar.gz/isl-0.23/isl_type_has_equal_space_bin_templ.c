#undef TYPE1
#define TYPE1		TYPE
#undef TYPE2
#define TYPE2		TYPE
#undef TYPE_PAIR
#define TYPE_PAIR	TYPE

#include "isl_type_has_equal_space_templ.c"
