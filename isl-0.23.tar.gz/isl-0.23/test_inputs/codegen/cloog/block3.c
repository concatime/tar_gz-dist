S1();
for (int c0 = 0; c0 <= 1; c0 += 1)
  S3(c0);
S2();
