if (n >= 3 * floord(n + 1, 3))
  for (int c0 = m; c0 <= 5 * floord(n + 1, 3); c0 += 1)
    s0(c0);
