for (int c0 = 1; c0 <= 15; c0 += 1) {
  if (((-exprVar1 + 15) % 8) + c0 <= 15) {
    s2(c0);
    s0(c0);
    s4(c0);
    s3(c0);
    s1(c0);
  }
  if (((-exprVar1 + 15) % 8) + c0 <= 15 || (exprVar1 - c0 + 1) % 8 == 0)
    s5(c0);
}
