for (int c0 = 1; c0 <= 101; c0 += 1)
  for (int c1 = (c0 % 2) + c0; c1 <= 400; c1 += 2)
    s0(c0, c1);
