for (int c0 = 1; c0 <= 10; c0 += 1)
  for (int c1 = 10; c1 <= 100; c1 += 1)
    s0(c0, c1);
