for (int c0 = -3; c0 <= 96; c0 += 1)
  s0(c0, c0 + 4);
