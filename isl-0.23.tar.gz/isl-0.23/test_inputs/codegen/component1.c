A();
for (int c0 = 0; c0 <= 9; c0 += 1)
  B(c0);
