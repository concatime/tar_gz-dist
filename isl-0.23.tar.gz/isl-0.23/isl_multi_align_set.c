#define ALIGN_DOMBASE set
#define ALIGN_DOM isl_set

#include <isl_multi_align_templ.c>

#undef ALIGN_DOMBASE
#undef ALIGN_DOM
