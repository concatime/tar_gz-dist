#!/bin/sh

TESTPROG=${1}
${TESTPROG} >&-
