
This .obj viewer is based on the "smooth" program by Nate Robins
found in the Kilgard GLUT package.

The alpine sky box textures come from http://www.hazelwhorley.com/skyboxtex3_bitmaps.html

The bunny.obj and buddha.obj models come from Stanford.

The GreatLakesBiplaneHP.obj model comes from http://www.sharecg.com/v/25978/3D-Model/Great-Lakes-Biplane-Model

The bobcat.obj model comes from http://www.sharecg.com/v/24771/3D-Model/Bobcat,3d-studio-and-wavefront-objects

The .obj file reader code in glm.c isn't perfect.  Not all .obj files are
parsed correctly.  There are often mistakes in material-to-triangle assignments.


Mouse:
   Left = rotate
   Middle = scale
   Right = menu

Keyboard:
   See pop-up menu for keyboard shortcuts, or press 'h'.
