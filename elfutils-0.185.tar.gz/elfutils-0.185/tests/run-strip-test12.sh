original=testfile-riscv64
stripped=testfile-riscv64-s

. $srcdir/run-strip-test.sh
