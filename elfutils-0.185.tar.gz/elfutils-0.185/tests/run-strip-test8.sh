original=testfile47
stripped=testfile48
debugfile=testfile48.debug

. $srcdir/run-strip-test.sh
