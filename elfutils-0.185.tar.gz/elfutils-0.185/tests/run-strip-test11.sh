original=testfile-m68k
stripped=testfile-m68k-s

. $srcdir/run-strip-test.sh
