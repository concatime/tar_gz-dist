original=testfile11
stripped=testfile37
debugfile=testfile37.debug

. $srcdir/run-strip-test.sh
