original=testfile12
stripped=testfile35
debugfile=testfile35.debug

. $srcdir/run-strip-test.sh
