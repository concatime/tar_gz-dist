#define BITS 64
#include "sparc_corenote.c"
