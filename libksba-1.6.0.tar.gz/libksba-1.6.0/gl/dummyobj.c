/* dummyobj.c -- Dummy to help libtool with a broken ar(1) */

int 
_ksba_dummyobj_for_broken_ar (int foo)
{
  return foo;
}


